# Contract Monthly Claim System

## Project Overview

The **Contract Monthly Claim System (CMCS)** is a .NET web-based application designed to streamline the process of submitting and approving monthly claims for Independent Contractor (IC) lecturers. This project involves developing a user-friendly GUI using WPF (Windows Presentation Foundation) and implementing various functionalities for managing claims. The application includes dashboards for lecturers, programme coordinators, and academic managers, with features for submitting claims, tracking claim status, and uploading supporting documents.

## Project Structure

1. **Lecturer Dashboard**: Interface for lecturers to view and manage their claims, including submission and status tracking.
2. **Claim Submission Form**: Form for lecturers to submit new claims, including fields for claim details and document upload.
3. **Claim Status Tracking**: Allows lecturers to track the status of their submitted claims.
4. **Document Upload Section**: Interface for uploading additional documents related to claims.
5. **Programme Coordinator Dashboard**: For reviewing and managing claims, with options for approval or rejection.
6. **Academic Manager Dashboard**: Provides an overview of all claims and options for generating reports.
7. **Settings Page**: Allows users to update account details, configure application settings, and view application information.

## Data Flow Diagram
![Data Flow](https://github.com/user-attachments/assets/a3f59809-54fc-48ec-9b26-ae84c3d53193)



## Setup Instructions

1. **Clone the Repository**

   ```bash
   git clone https://github.com/VCDN-2024/prog6212-poe-part-1-mikylenaidoo.git
